import boto3
import json
import os
from datetime import datetime, timedelta

def handler(event, context):
    logs_client = boto3.client('logs')
    log_group_names = json.loads(os.environ['LOG_GROUP_NAMES'])
    
    cutoff_time = datetime.now() - timedelta(days=1)
    
    for log_group in log_group_names:
        try:
            # Delete log streams older than 1 day
            response = logs_client.describe_log_streams(
                logGroupName=log_group,
                orderBy='LastEventTime',
                descending=True
            )
            
            for stream in response['logStreams']:
                if 'lastEventTimestamp' in stream:
                    stream_time = datetime.fromtimestamp(stream['lastEventTimestamp'] / 1000)
                    if stream_time < cutoff_time:
                        logs_client.delete_log_stream(
                            logGroupName=log_group,
                            logStreamName=stream['logStreamName']
                        )
                        print(f"Deleted stream: {stream['logStreamName']}")
        except Exception as e:
            print(f"Error cleaning up {log_group}: {e}")
    
    return {"statusCode": 200, "body": "Cleanup completed"}
